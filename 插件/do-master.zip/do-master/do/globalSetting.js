//默认选项
module.exports.options ={
    dOption:{
		//是否调试状态
		isDebugStatus:true
    }
};