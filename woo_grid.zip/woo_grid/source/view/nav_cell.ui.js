/**
 * related to nav_cell.ui
 * 
 * @Author : 18507717466
 * @Timestamp : 2016-10-06
 */
var root = ui("$");
root.setMapping({
	"do_ImageView_1.source":"gridImage"
})